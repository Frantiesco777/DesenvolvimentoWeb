<?php
// buscar_temporadas.php
require_once("conexao.php");

header('Content-Type: application/json');

$animeId = isset($_GET['anime_id']) ? intval($_GET['anime_id']) : 0;

if ($animeId <= 0) {
    echo json_encode([]);
    exit;
}

$stmt = $conexao->prepare("SELECT id, numero, nome FROM temporadas_animes WHERE anime_id = ? ORDER BY numero ASC");
$stmt->bind_param("i", $animeId);
$stmt->execute();
$result = $stmt->get_result();

$temporadas = [];
while ($row = $result->fetch_assoc()) {
    $temporadas[] = $row;
}

echo json_encode($temporadas);
