<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login_admin.php");
    exit;
}

require_once("conexao.php");

/**
 * Função para adicionar nova temporada com episódios.
 * @param mysqli $conexao
 * @param int $animeId
 * @param int $qtdEps
 * @return string|null Retorna mensagem de erro ou null se sucesso.
 */
function adicionarTemporada(mysqli $conexao, int $animeId, int $qtdEps): ?string {
    if ($animeId <= 0 || $qtdEps <= 0) {
        return "ID do anime e quantidade de episódios devem ser maiores que zero.";
    }
    try {
        // Descobre o próximo número da temporada
        $stmt = $conexao->prepare("SELECT MAX(numero) as max_num FROM temporadas_animes WHERE anime_id = ?");
        $stmt->bind_param("i", $animeId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $proxNum = intval($result['max_num'] ?? 0) + 1;

        // Insere nova temporada
        $nomeTemp = "Temporada " . $proxNum;
        $stmt = $conexao->prepare("INSERT INTO temporadas_animes (anime_id, numero, nome) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $animeId, $proxNum, $nomeTemp);
        $stmt->execute();
        $temporadaId = $conexao->insert_id;

        // Insere episódios sequenciais
        for ($ep = 1; $ep <= $qtdEps; $ep++) {
            $link = "eps/ep_anime{$animeId}_temp{$proxNum}_ep{$ep}.html";
            $stmt = $conexao->prepare("INSERT INTO episodios (temporada_id, numero, link) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $temporadaId, $ep, $link);
            $stmt->execute();

            $html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Episódio $ep</title></head><body><h1>Anime ID: $animeId - Temporada $proxNum - Episódio $ep</h1><p>Conteúdo em breve...</p></body></html>";
            file_put_contents($link, $html);
        }
    } catch (Exception $e) {
        return "Erro ao adicionar temporada: " . $e->getMessage();
    }
    return null;
}

/**
 * Função para adicionar episódios a uma temporada existente.
 * @param mysqli $conexao
 * @param int $temporadaId
 * @param int $qtdEpsAdd
 * @return string|null Retorna mensagem de erro ou null se sucesso.
 */
function adicionarEpisodios(mysqli $conexao, int $temporadaId, int $qtdEpsAdd): ?string {
    if ($temporadaId <= 0 || $qtdEpsAdd <= 0) {
        return "ID da temporada e quantidade de episódios devem ser maiores que zero.";
    }
    try {
        // Busca dados da temporada
        $stmt = $conexao->prepare("SELECT anime_id, numero FROM temporadas_animes WHERE id = ?");
        $stmt->bind_param("i", $temporadaId);
        $stmt->execute();
        $tempInfo = $stmt->get_result()->fetch_assoc();

        if (!$tempInfo) {
            return "Temporada não encontrada.";
        }

        $animeId = intval($tempInfo['anime_id']);
        $tempNum = intval($tempInfo['numero']);

        // Busca último episódio já cadastrado
        $stmt = $conexao->prepare("SELECT MAX(numero) as max_ep FROM episodios WHERE temporada_id = ?");
        $stmt->bind_param("i", $temporadaId);
        $stmt->execute();
        $lastEpResult = $stmt->get_result()->fetch_assoc();
        $ultimoEp = intval($lastEpResult['max_ep'] ?? 0);

        // Insere novos episódios incrementais
        for ($i = 1; $i <= $qtdEpsAdd; $i++) {
            $epNum = $ultimoEp + $i;
            $link = "eps/ep_anime{$animeId}_temp{$tempNum}_ep{$epNum}.html";
            $stmt = $conexao->prepare("INSERT INTO episodios (temporada_id, numero, link) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $temporadaId, $epNum, $link);
            $stmt->execute();

            $html = "<!DOCTYPE html><html><head><meta charset='utf-8'><title>Episódio $epNum</title></head><body><h1>Anime ID: $animeId - Temporada $tempNum - Episódio $epNum</h1><p>Conteúdo em breve...</p></body></html>";
            file_put_contents($link, $html);
        }
    } catch (Exception $e) {
        return "Erro ao adicionar episódios: " . $e->getMessage();
    }
    return null;
}

// Processa submissão dos formulários
$mensagemErro = null;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (isset($_POST['anime_id'], $_POST['qtd_eps']) && !isset($_POST['temporada_id'])) {
        // Adicionar temporada
        $mensagemErro = adicionarTemporada($conexao, intval($_POST['anime_id']), intval($_POST['qtd_eps']));
        if (!$mensagemErro) {
            echo "<script>alert('Temporada adicionada com sucesso!');</script>";
        }
    } elseif (isset($_POST['temporada_id'], $_POST['qtd_eps_add'])) {
        // Adicionar episódios
        $mensagemErro = adicionarEpisodios($conexao, intval($_POST['temporada_id']), intval($_POST['qtd_eps_add']));
        if (!$mensagemErro) {
            echo "<script>alert('Episódios adicionados com sucesso!');</script>";
        }
    }
}

// Busca lista de animes
$sql = "SELECT a.id, a.nome, a.genero, i.estudio 
        FROM animes_geral a 
        LEFT JOIN informacoes i ON a.id = i.anime_id 
        ORDER BY a.nome ASC";
$resultado = $conexao->query($sql);

/**
 * Função para contar temporadas de um anime.
 */
function contarTemporadas(mysqli $conexao, int $animeId): int {
    $stmt = $conexao->prepare("SELECT COUNT(*) as total FROM temporadas_animes WHERE anime_id = ?");
    $stmt->bind_param("i", $animeId);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    return intval($res['total'] ?? 0);
}

/**
 * Função para contar episódios de um anime.
 */
function contarEpisodios(mysqli $conexao, int $animeId): int {
    $stmt = $conexao->prepare("SELECT COUNT(*) as total FROM episodios WHERE temporada_id IN (SELECT id FROM temporadas_animes WHERE anime_id = ?)");
    $stmt->bind_param("i", $animeId);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    return intval($res['total'] ?? 0);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Catálogo de Animes</title>
<style>
    body {
        background: #121212;
        color: #fff;
        font-family: Arial, sans-serif;
        padding: 30px;
    }
    h1 {
        color: #f9a825;
        margin-bottom: 30px;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: #1e1e1e;
        box-shadow: 0 0 10px #f9a825;
        border-radius: 10px;
        overflow: hidden;
    }
    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #333;
    }
    th {
        background-color: #f9a825;
        color: #121212;
    }
    tr:hover {
        background-color: #333;
    }
    .voltar {
        display: inline-block;
        margin-bottom: 20px;
        padding: 10px 20px;
        background-color: #4caf50;
        color: white;
        text-decoration: none;
        font-weight: bold;
        border-radius: 5px;
        transition: background 0.3s;
    }
    .voltar:hover {
        background-color: #388e3c;
    }
    button {
        background-color: #fbc02d;
        color: #000;
        padding: 6px 12px;
        border: none;
        border-radius: 5px;
        font-weight: bold;
        cursor: pointer;
        margin-right: 5px;
    }
    .modal {
        display: none;
        position: fixed;
        z-index: 10;
        left: 0; top: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0,0,0,0.6);
    }
    .modal-content {
        background: #1e1e1e;
        margin: 10% auto;
        padding: 20px;
        border: 2px solid #f9a825;
        border-radius: 10px;
        width: 320px;
        box-shadow: 0 0 15px #f9a825;
    }
    .modal-content h3 {
        margin-top: 0;
        color: #fbc02d;
    }
    .modal-content input,
    .modal-content select {
        width: 100%;
        padding: 8px;
        margin-top: 10px;
        background: #222;
        color: #fff;
        border: none;
        border-radius: 5px;
    }
    .modal-content button {
        margin-top: 15px;
        width: 100%;
        background-color: #4caf50;
        color: #fff;
    }
    .fechar {
        float: right;
        font-size: 20px;
        cursor: pointer;
        color: #fff;
    }
</style>
</head>
<body>

<a href="cadastro.php" class="voltar">← Voltar para Cadastro</a>
<h1>Catálogo de Animes</h1>

<?php if ($mensagemErro): ?>
    <p style="color:#f44336; font-weight:bold;"><?= htmlspecialchars($mensagemErro) ?></p>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>Nome</th>
            <th>Gênero</th>
            <th>Estúdio</th>
            <th>Temporadas</th>
            <th>Total de Eps</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($resultado->num_rows > 0): ?>
            <?php while ($row = $resultado->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['nome']) ?></td>
                <td><?= htmlspecialchars($row['genero']) ?></td>
                <td><?= htmlspecialchars($row['estudio'] ?? '—') ?></td>
                <td><?= contarTemporadas($conexao, $row['id']) ?></td>
                <td><?= contarEpisodios($conexao, $row['id']) ?></td>
                <td>
                    <button onclick="abrirModalTemporada(<?= $row['id'] ?>)">Adicionar Temporada</button>
                    <button onclick="abrirModalEpisodios(<?= $row['id'] ?>)">Adicionar Episódios</button>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6">Nenhum anime cadastrado.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Modal para adicionar temporada -->
<div id="modalTemporada" class="modal">
    <div class="modal-content">
        <span class="fechar" onclick="fecharModal('modalTemporada')">&times;</span>
        <h3>Nova Temporada</h3>
        <form method="POST" id="formTemporada">
            <input type="hidden" name="anime_id" id="anime_id_temp">
            <label>Qtd de Episódios:</label>
            <input type="number" name="qtd_eps" min="1" required>
            <button type="submit">Adicionar</button>
        </form>
    </div>
</div>

<!-- Modal para adicionar episódios -->
<div id="modalEpisodios" class="modal">
    <div class="modal-content">
        <span class="fechar" onclick="fecharModal('modalEpisodios')">&times;</span>
        <h3>Adicionar Episódios</h3>
        <form method="POST" id="formEpisodios">
            <input type="hidden" name="anime_id" id="anime_id_eps">
            <label>Selecione a Temporada:</label>
            <select name="temporada_id" id="temporada_select" required>
                <option value="">Carregando...</option>
            </select>
            <label>Qtd de Episódios a adicionar:</label>
            <input type="number" name="qtd_eps_add" min="1" required>
            <button type="submit">Adicionar</button>
        </form>
    </div>
</div>

<script>
// Abre modal de adicionar temporada
function abrirModalTemporada(animeId) {
    document.getElementById('anime_id_temp').value = animeId;
    document.getElementById('modalTemporada').style.display = 'block';
}

// Abre modal de adicionar episódios e carrega temporadas
function abrirModalEpisodios(animeId) {
    document.getElementById('anime_id_eps').value = animeId;
    document.getElementById('modalEpisodios').style.display = 'block';
    carregarTemporadas(animeId);
}

// Fecha modal
function fecharModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Fecha modal ao clicar fora do conteúdo
window.onclick = function(event) {
    ['modalTemporada', 'modalEpisodios'].forEach(id => {
        const modal = document.getElementById(id);
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
}

// Carrega temporadas via AJAX para o select
function carregarTemporadas(animeId) {
    const select = document.getElementById('temporada_select');
    select.innerHTML = '<option value="">Carregando...</option>';

    fetch('buscar_temporadas.php?anime_id=' + animeId)
        .then(response => response.json())
        .then(data => {
            if (data.length === 0) {
                select.innerHTML = '<option value="">Nenhuma temporada cadastrada</option>';
            } else {
                select.innerHTML = '';
                data.forEach(temp => {
                    const option = document.createElement('option');
                    option.value = temp.id;
                    option.textContent = `Temporada ${temp.numero} - ${temp.nome}`;
                    select.appendChild(option);
                });
            }
        })
        .catch(() => {
            select.innerHTML = '<option value="">Erro ao carregar temporadas</option>';
        });
}
</script>

</body>
</html>
