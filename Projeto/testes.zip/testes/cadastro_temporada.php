<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login_admin.php");
    exit;
}

require_once("conexao.php");

function adicionarTemporadaComEpsNoBanco(mysqli $conexao, int $animeId, int $qtdEps): ?string {
    if ($animeId <= 0 || $qtdEps <= 0) {
        return "ID do anime e quantidade de episódios devem ser maiores que zero.";
    }
    try {
        // Busca o maior número da temporada para esse anime
        $stmt = $conexao->prepare("SELECT MAX(numero) as max_num FROM temporadas_animes WHERE anime_id = ?");
        $stmt->bind_param("i", $animeId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $proxNum = intval($result['max_num'] ?? 0) + 1;

        // Insere a nova temporada
        $nomeTemp = "Temporada " . $proxNum;
        $stmt = $conexao->prepare("INSERT INTO temporadas_animes (anime_id, numero, nome) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $animeId, $proxNum, $nomeTemp);
        $stmt->execute();
        $temporadaId = $conexao->insert_id;

        // Insere os episódios
        for ($ep = 1; $ep <= $qtdEps; $ep++) {
            // Apenas um nome identificador, não arquivo físico
            $nomeArquivo = "ep_anime{$animeId}_temp{$proxNum}_ep{$ep}.html";

            // Conteúdo salvo no banco (só corpo do episódio)
            $conteudo = "<h1>Anime ID: $animeId - Temporada $proxNum - Episódio $ep</h1><p>Conteúdo em breve...</p>";

            $stmtEp = $conexao->prepare("INSERT INTO episodios (temporada_id, numero, link, conteudo) VALUES (?, ?, ?, ?)");
            $stmtEp->bind_param("iiss", $temporadaId, $ep, $nomeArquivo, $conteudo);
            $stmtEp->execute();
        }
    } catch (Exception $e) {
        return "Erro ao adicionar temporada: " . $e->getMessage();
    }
    return null;
}

$mensagem = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $animeId = intval($_POST['anime_id'] ?? 0);
    $qtdEps = intval($_POST['qtd_eps'] ?? 0);

    if ($animeId > 0 && $qtdEps > 0) {
        $mensagem = adicionarTemporadaComEpsNoBanco($conexao, $animeId, $qtdEps);
        if ($mensagem === null) {
            $mensagem = "Temporada e episódios adicionados com sucesso!";
        }
    } else {
        $mensagem = "Preencha todos os campos corretamente.";
    }
}

// Consulta para popular select de animes
$result = $conexao->query("SELECT id, nome FROM animes_geral ORDER BY nome ASC");
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8" />
<title>Adicionar Temporada e Episódios</title>
<style>
  body { background: #121212; color: #fff; font-family: Arial, sans-serif; padding: 20px; }
  label, select, input { display: block; margin-bottom: 10px; font-size: 16px; }
  select, input[type=number] {
    padding: 8px; width: 250px; border-radius: 5px; border: none; background: #222; color: #eee;
  }
  button {
    padding: 10px 20px; background-color: #f9a825; border: none; border-radius: 6px;
    font-weight: bold; cursor: pointer; color: #121212; font-size: 16px;
  }
  button:hover { background-color: #c7a200; }
  .mensagem {
    margin-top: 15px; padding: 10px; background-color: #333; border-radius: 6px; max-width: 400px;
  }
  a {
    color: #f9a825; text-decoration: none; display: inline-block; margin-top: 20px;
  }
  a:hover { text-decoration: underline; }
</style>
</head>
<body>
  <h1>Adicionar Temporada e Episódios</h1>

  <?php if ($mensagem): ?>
    <div class="mensagem"><?= htmlspecialchars($mensagem) ?></div>
  <?php endif; ?>

  <form method="POST" action="">
    <label for="anime_id">Anime:</label>
    <select name="anime_id" id="anime_id" required>
      <option value="">-- Selecione um anime --</option>
      <?php while ($row = $result->fetch_assoc()): ?>
        <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['nome']) ?></option>
      <?php endwhile; ?>
    </select>

    <label for="qtd_eps">Quantidade de episódios na nova temporada:</label>
    <input type="number" name="qtd_eps" id="qtd_eps" min="1" required>

    <button type="submit">Adicionar Temporada</button>
  </form>

  <a href="catalogo.php">← Voltar para catálogo</a>
</body>
</html>
